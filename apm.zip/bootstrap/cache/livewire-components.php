<?php return array (
  'apms' => 'App\\Http\\Livewire\\Apms',
  'area-apms' => 'App\\Http\\Livewire\\AreaApms',
  'file-upload' => 'App\\Http\\Livewire\\FileUpload',
  'kriteria-apms' => 'App\\Http\\Livewire\\KriteriaApms',
);