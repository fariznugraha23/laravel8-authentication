<?php $__env->startComponent($view, $params); ?>
    <?php echo $manager->initialDehydrate()->toInitialResponse()->effects['html'];; ?>

<?php if (isset($__componentOriginale7c6616875b34e3f53343f67cca22d88de00f61f)): ?>
<?php $component = $__componentOriginale7c6616875b34e3f53343f67cca22d88de00f61f; ?>
<?php unset($__componentOriginale7c6616875b34e3f53343f67cca22d88de00f61f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\laravel8-authentication\vendor\livewire\livewire\src/Macros/livewire-view-component.blade.php ENDPATH**/ ?>