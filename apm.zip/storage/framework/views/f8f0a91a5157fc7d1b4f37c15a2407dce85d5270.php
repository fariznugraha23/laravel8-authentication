 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Upload APM
    </h2>
 <?php $__env->endSlot(); ?>
<div class="py-12">
    <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
           
            <table class="table-fixed w-full">
                <tr>
                    <th>Area</th>
                    <td>data area</td>
                </tr>
                <tr>
                    <th>Area RB</th>
                    <td>data area RB</td>
                </tr>  
                <tr>
                    <th>test</th>
                    <td>isi test</td>
                </tr>  
                <tr>
                    <th>coba</th>
                    <td>isi coba</td>
                </tr>       
            </table>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel8-authentication\resources\views/upload-data.blade.php ENDPATH**/ ?>